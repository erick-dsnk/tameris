

class Emoji:
    def __init__(
        self,
        id,
        name,
        is_animated = False
    ):
        self.id = id
        self.name = name
        self.is_animated = is_animated