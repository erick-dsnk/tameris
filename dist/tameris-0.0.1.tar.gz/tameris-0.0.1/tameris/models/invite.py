class Invite:
    def __init__(
        self,
        code,
        channel
    ):
        self.code = code
        self.channel = channel